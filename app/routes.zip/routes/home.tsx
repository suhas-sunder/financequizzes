import { json } from "@remix-run/node";
import type { Route } from "./+types/home";
import { useLoaderData } from "react-router";

interface LoaderData {
  nowISO: string;
  faqs: { q: string; a: string }[];
}

export function meta({}: Route.MetaArgs) {
  const title = "Finance Quizzes | Test Your Finance and Investing Knowledge";
  const description =
    "Free finance quizzes to test your money knowledge. Take focused quizzes in personal finance, investing, and banking with quick scoring and no signup.";
  const url = "https://www.financequizzes.com/";

  return [
    { title },
    { name: "description", content: description },
    { property: "og:title", content: title },
    { property: "og:description", content: description },
    { property: "og:type", content: "website" },
    { property: "og:url", content: url },
    { name: "twitter:card", content: "summary_large_image" },
    { name: "theme-color", content: "#0B1B2B" },
    { name: "robots", content: "index,follow" },
  ];
}

const priorityRoutes = [
  {
    icon: "🧠",
    t: "General Finance Quiz",
    d: "Quick challenge + full-quiz mode. Covers core money concepts.",
    href: "/general-finance-quizzes",
  },
  {
    icon: "💰",
    t: "Personal Finance Quiz",
    d: "Budgeting, saving, debt, and credit basics.",
    href: "/learn-personal-finance-quizzes",
  },
  {
    icon: "📈",
    t: "Investing Quiz",
    d: "Risk, diversification, markets, and long-term thinking.",
    href: "/learn-investing-quizzes",
  },
];

const allCategoryRoutes = [
  ...priorityRoutes,
  {
    icon: "🏦",
    t: "Banking & Credit",
    d: "Accounts, loans, interest, and how banks work.",
    href: "/learn-banking-quizzes",
  },
  {
    icon: "📊",
    t: "Business Finance",
    d: "Revenue, profit, and cash flow fundamentals.",
    href: "/learn-business-quizzes",
  },
  {
    icon: "🌍",
    t: "Economics",
    d: "Inflation, markets, and macro basics.",
    href: "/learn-economics-quizzes",
  },
  {
    icon: "🛡️",
    t: "Insurance",
    d: "Premiums, deductibles, and how coverage works.",
    href: "/learn-insurance-quizzes",
  },
  {
    icon: "⏳",
    t: "Money History",
    d: "How money evolved over time.",
    href: "/learn-history-quizzes",
  },
];

export function loader() {
  return json<LoaderData>({
    nowISO: new Date().toISOString(),
    faqs: [
      {
        q: "Are the quizzes free?",
        a: "Yes. All quizzes are free and you can play as many times as you want.",
      },
      {
        q: "Do I need an account?",
        a: "No. There is no signup. Some stats may be saved locally in your browser.",
      },
      {
        q: "Is this financial advice?",
        a: "No. This site is educational only and does not provide financial, tax, or investment advice.",
      },
      {
        q: "What should I start with?",
        a: "Start with the General Finance Quiz, then take focused quizzes in Personal Finance or Investing.",
      },
      {
        q: "How long does a quiz take?",
        a: "Most quizzes are designed to be quick. You can usually finish a round in a few minutes.",
      },
    ],
  });
}

export default function Home({}: Route.ComponentProps) {
  const { faqs } = useLoaderData() as LoaderData;

  return (
    <main className="bg-white text-[#0B1B2B]">
      {/* HERO */}
      <section
        className="relative bg-[#F9FBFD] pt-10 pb-14 px-4 border-b border-slate-200"
        style={{
          backgroundImage:
            "radial-gradient(circle at 1px 1px, #E5E9EE 1px, transparent 0)",
          backgroundSize: "20px 20px",
        }}
      >
        <div className="mx-auto max-w-6xl">
          <div className="text-center">
            <div className="mb-4 inline-block rounded-full bg-teal-100 px-4 pt-1 pb-2 text-xs font-semibold text-teal-700">
              Test your finance and investing knowledge
            </div>
            <h1 className="text-3xl sm:text-5xl font-extrabold text-[#0B1B2B] mb-5 tracking-tight">
              Free Finance Quizzes
            </h1>
            <p className="max-w-2xl mx-auto text-slate-700 text-base sm:text-lg leading-relaxed">
              Take quick, focused quizzes in personal finance, investing, and banking.
              Get a simple score summary and move on. No signup.
            </p>

            <div className="mt-8 flex flex-col sm:flex-row gap-3 justify-center">
              <a
                href="/general-finance-quizzes"
                className="rounded-xl bg-teal-700 px-6 py-3 text-white font-semibold text-base hover:bg-teal-800 transition"
              >
                Start the General Finance Quiz
              </a>
              <a
                href="/learn-personal-finance-quizzes"
                className="rounded-xl border border-slate-300 bg-white px-6 py-3 text-[#0B1B2B] font-semibold text-base hover:bg-slate-50 transition"
              >
                Take a Personal Finance Quiz
              </a>
              <a
                href="/learn-investing-quizzes"
                className="rounded-xl border border-slate-300 bg-white px-6 py-3 text-[#0B1B2B] font-semibold text-base hover:bg-slate-50 transition"
              >
                Take an Investing Quiz
              </a>
            </div>

            <p className="mt-5 text-sm text-slate-600">
              Looking for specific topics like budgeting, saving, or retirement basics?
              Those focused quiz pages are being added next.
            </p>
          </div>
        </div>
      </section>

      {/* PRIORITY PATHS */}
      <section className="mx-auto max-w-6xl px-4 sm:px-6 py-14 border-b border-slate-200">
        <div className="text-center">
          <h2 className="text-3xl font-extrabold mb-3 text-[#0B1B2B]">
            Start with a focused quiz
          </h2>
          <p className="max-w-2xl mx-auto mb-10 text-slate-700 text-base sm:text-lg">
            These are the core tracks most people want: general finance, personal finance, and investing.
          </p>
        </div>

        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6 text-left">
          {priorityRoutes.map((c) => (
            <a
              key={c.t}
              href={c.href}
              className="group flex flex-col justify-between rounded-2xl border border-slate-200 bg-white p-7 shadow-sm hover:shadow-md hover:-translate-y-0.5 transition"
            >
              <div className="flex items-center gap-3 mb-3">
                <span className="text-3xl">{c.icon}</span>
                <h3 className="text-lg font-semibold text-[#0B1B2B] group-hover:text-teal-700 transition-colors">
                  {c.t}
                </h3>
              </div>
              <p className="text-slate-700 text-sm leading-relaxed flex-1">{c.d}</p>
              <div className="text-teal-700 mt-4 text-sm font-semibold group-hover:underline">
                Start →
              </div>
            </a>
          ))}
        </div>
      </section>

      {/* VALUE PROPS */}
      <section className="mx-auto max-w-6xl px-4 sm:px-6 py-14 border-b border-slate-200">
        <div className="grid lg:grid-cols-2 gap-10 items-start">
          <div>
            <h2 className="text-3xl font-extrabold mb-4 text-[#0B1B2B]">
              One goal: a clean self-assessment
            </h2>
            <p className="text-slate-700 text-base sm:text-lg leading-relaxed mb-5">
              FinanceQuizzes is built for fast feedback. You answer questions, get a simple score summary,
              and you are done. No long articles and no calculators.
            </p>
            <p className="text-slate-700 text-base sm:text-lg leading-relaxed">
              If you want to go deeper, take a more specific quiz category.
              The most lucrative intent areas are personal finance, credit, investing basics, saving, budgeting,
              and retirement concepts.
            </p>
          </div>

          <div className="rounded-3xl border border-slate-200 bg-[#F9FBFD] p-8">
            <h3 className="text-xl font-bold mb-4 text-[#0B1B2B]">What you can expect</h3>
            <ul className="space-y-3 text-slate-700 text-base">
              <li className="flex gap-3">
                <span className="mt-0.5">✅</span>
                <span>Short quizzes with quick scoring</span>
              </li>
              <li className="flex gap-3">
                <span className="mt-0.5">✅</span>
                <span>Beginner-friendly questions with clear wording</span>
              </li>
              <li className="flex gap-3">
                <span className="mt-0.5">✅</span>
                <span>No signup and no personal data required</span>
              </li>
              <li className="flex gap-3">
                <span className="mt-0.5">✅</span>
                <span>Educational only, not advice or recommendations</span>
              </li>
            </ul>
            <div className="mt-6 flex flex-col sm:flex-row gap-3">
              <a
                href="/general-finance-quizzes"
                className="rounded-xl bg-teal-700 px-5 py-2.5 text-white font-semibold text-base hover:bg-teal-800 transition text-center"
              >
                Take the General Finance Quiz
              </a>
              <a
                href="#all-categories"
                className="rounded-xl border border-slate-300 bg-white px-5 py-2.5 text-[#0B1B2B] font-semibold text-base hover:bg-slate-50 transition text-center"
              >
                Browse all categories
              </a>
            </div>
          </div>
        </div>
      </section>

      {/* ALL CATEGORIES */}
      <section
        id="all-categories"
        className="mx-auto max-w-6xl px-4 sm:px-6 py-16 border-b border-slate-200 text-center"
      >
        <h2 className="text-3xl font-extrabold mb-4 text-[#0B1B2B]">All quiz categories</h2>
        <p className="max-w-2xl mx-auto mb-10 text-slate-700 text-base sm:text-lg">
          Explore every existing quiz category. The first row is prioritized because it matches the strongest search intent.
        </p>

        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6 text-left">
          {allCategoryRoutes.map((c) => (
            <a
              key={c.t}
              href={c.href}
              className="group flex flex-col justify-between rounded-xl border border-slate-200 bg-white p-6 shadow-sm hover:shadow-md hover:-translate-y-0.5 transition"
            >
              <div className="flex items-center gap-3 mb-3">
                <span className="text-3xl">{c.icon}</span>
                <h3 className="text-lg font-semibold text-[#0B1B2B] group-hover:text-teal-700 transition-colors">
                  {c.t}
                </h3>
              </div>
              <p className="text-slate-700 text-sm leading-relaxed flex-1">{c.d}</p>
              <div className="text-teal-700 mt-4 text-sm font-semibold group-hover:underline">
                Open →
              </div>
            </a>
          ))}
        </div>
      </section>

      {/* FAQ */}
      <section className="mx-auto max-w-5xl px-4 sm:px-6 py-16">
        <h2 className="text-3xl font-extrabold text-[#0B1B2B] mb-4 text-center">
          Finance quiz FAQ
        </h2>
        <p className="text-slate-700 text-center max-w-2xl mx-auto mb-10">
          Short answers to common questions about how the quizzes work.
        </p>

        <div className="rounded-2xl border border-slate-200 bg-white shadow-sm divide-y divide-slate-200">
          {faqs.map((f, i) => (
            <div key={i} className="p-6">
              <p className="font-semibold text-lg text-[#0B1B2B] mb-2">
                {f.q}
              </p>
              <p className="text-slate-700">{f.a}</p>
            </div>
          ))}
        </div>

        {/* Structured data: WebSite + FAQPage */}
        <script
          type="application/ld+json"
          dangerouslySetInnerHTML={{
            __html: JSON.stringify({
              "@context": "https://schema.org",
              "@type": "WebSite",
              name: "FinanceQuizzes",
              url: "https://www.financequizzes.com/",
            }),
          }}
        />

        <script
          type="application/ld+json"
          dangerouslySetInnerHTML={{
            __html: JSON.stringify({
              "@context": "https://schema.org",
              "@type": "FAQPage",
              mainEntity: faqs.map((f) => ({
                "@type": "Question",
                name: f.q,
                acceptedAnswer: {
                  "@type": "Answer",
                  text: f.a,
                },
              })),
            }),
          }}
        />
      </section>
    </main>
  );
}
