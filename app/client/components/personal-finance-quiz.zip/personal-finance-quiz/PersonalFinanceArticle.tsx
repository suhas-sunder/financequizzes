import {
  PERSONAL_FINANCE_QUIZ_CATEGORIES,
  PERSONAL_FINANCE_QUIZ_INTENT,
  PERSONAL_FINANCE_QUIZ_SCORE_BANDS,
} from "./personalFinanceQuizData";

export function PersonalFinanceArticle() {
  const { topicLabel, focus } = PERSONAL_FINANCE_QUIZ_INTENT;

  const chips = PERSONAL_FINANCE_QUIZ_CATEGORIES.map((c) => c.label);

  return (
    <section
      id="about-this-quiz"
      className="mx-auto border-t border-slate-200 bg-gradient-to-b from-slate-50 to-white"
    >
      <div className="mx-auto max-w-6xl px-6 pt-12">
        <header className="mx-auto max-w-4xl text-center space-y-4">
          <div className="inline-flex items-center gap-2 rounded-full border border-emerald-200 bg-emerald-50 px-4 py-1.5 text-sm font-semibold text-emerald-800">
            <span className="h-2 w-2 rounded-full bg-emerald-600" />
            FinanceQuizzes
          </div>

          <h2 className="text-3xl md:text-4xl font-extrabold text-[#0B1B2B] tracking-tight">
            About this {topicLabel} quiz
          </h2>

          <p className="mx-auto max-w-2xl text-slate-600">
            {focus}
          </p>

          <div className="mx-auto mt-2 flex max-w-3xl flex-wrap justify-center gap-2">
            {chips.map((label) => (
              <span
                key={label}
                className="rounded-full border border-slate-200 bg-white px-3 py-1 text-xs font-semibold text-slate-700 shadow-sm"
              >
                {label}
              </span>
            ))}
          </div>
        </header>

        <div className="mx-auto mt-14 max-w-5xl grid grid-cols-1 gap-6">
          <div className="rounded-2xl border border-slate-200 bg-white shadow-sm">
            <div className="flex items-start gap-4 p-8">
              <div className="mt-1 h-10 w-10 shrink-0 rounded-xl bg-emerald-50 border border-emerald-100 flex items-center justify-center">
                <span className="text-emerald-700 font-extrabold">1</span>
              </div>
              <div>
                <h3 className="text-xl font-extrabold text-[#0B1B2B]">
                  What this quiz is testing
                </h3>
                <p className="mt-2 text-slate-700 leading-relaxed">
                  This page focuses on everyday personal finance language: budgets, bills, saving, debt, and basic credit terms.
                  It avoids abstract market concepts and instead sticks to the words and decisions people use in ordinary household contexts.
                </p>
              </div>
            </div>
          </div>

          <div className="rounded-2xl border border-slate-200 bg-white shadow-sm">
            <div className="flex items-start gap-4 p-8">
              <div className="mt-1 h-10 w-10 shrink-0 rounded-xl bg-emerald-50 border border-emerald-100 flex items-center justify-center">
                <span className="text-emerald-700 font-extrabold">2</span>
              </div>
              <div>
                <h3 className="text-xl font-extrabold text-[#0B1B2B]">
                  How to improve fast
                </h3>
                <ul className="mt-3 space-y-2 text-slate-700 leading-relaxed list-disc pl-6">
                  <li>Read your bank and card statements and look up any unfamiliar line items (fees, interest, categories).</li>
                  <li>Learn the difference between statement balance, current balance, and minimum payment.</li>
                  <li>Practice writing a simple monthly budget: needs, wants, and saving or debt payoff.</li>
                  <li>Understand what affects credit scores at a basic level (payment history and utilization).</li>
                </ul>
              </div>
            </div>
          </div>

          <div className="rounded-2xl border border-slate-200 bg-white shadow-sm">
            <div className="flex items-start gap-4 p-8">
              <div className="mt-1 h-10 w-10 shrink-0 rounded-xl bg-emerald-50 border border-emerald-100 flex items-center justify-center">
                <span className="text-emerald-700 font-extrabold">3</span>
              </div>
              <div>
                <h3 className="text-xl font-extrabold text-[#0B1B2B]">
                  How to interpret your score
                </h3>
                <p className="mt-2 text-slate-700 leading-relaxed">
                  Your score reflects practical recognition of terms you see in real life. Use the bands below as a quick read.
                </p>

                <div className="mt-5 grid grid-cols-1 sm:grid-cols-2 gap-3">
                  {PERSONAL_FINANCE_QUIZ_SCORE_BANDS.map((b) => (
                    <div
                      key={b.key}
                      className="rounded-xl border border-slate-200 bg-slate-50 px-4 py-3"
                    >
                      <div className="text-sm font-extrabold text-[#0B1B2B]">
                        {b.label}
                      </div>
                      <div className="mt-1 text-sm text-slate-700">
                        {b.meaning}
                      </div>
                    </div>
                  ))}
                </div>

                <p className="mt-5 text-xs text-slate-500">
                  Note: This quiz is informational and not financial advice.
                </p>
              </div>
            </div>
          </div>
        </div>

        <div className="pb-12" />
      </div>
    </section>
  );
}
