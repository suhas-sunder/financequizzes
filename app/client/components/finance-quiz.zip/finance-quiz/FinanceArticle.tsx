export function FinanceArticle() {
  return (
    <section
      id="about-this-quiz"
      className="mx-auto max-w-5xl px-6 py-20 text-left border-b border-slate-200"
    >
      <div className="mx-auto max-w-4xl text-slate-700 leading-relaxed space-y-10">
        <h2 className="text-3xl font-bold text-[#0B1B2B] text-center">
          About this finance quiz
        </h2>

        <section className="space-y-4">
          <h3 className="text-2xl font-bold text-[#0B1B2B]">
            What this quiz tests
          </h3>
          <p>
            This finance quiz evaluates your ability to correctly interpret
            common personal finance terms as they are used in real situations.
            The focus is on recognition and understanding, not calculation or
            strategy. Each question checks whether a financial label or phrase
            registers correctly based on context, similar to how it appears on
            bank statements, account dashboards, loan summaries, and disclosure
            pages.
          </p>
          <p>
            It is designed for learners who want to verify that core finance
            language is clear and consistent in their mind. The quiz does not
            attempt to teach tactics, provide advice, or recommend actions. It
            strictly measures comprehension of commonly used financial terms.
          </p>
        </section>

        <section className="space-y-4">
          <h3 className="text-2xl font-bold text-[#0B1B2B]">
            Core finance concepts covered
          </h3>
          <p>
            Personal finance relies heavily on precise language. Small wording
            differences can change the meaning of a number or label entirely.
            This quiz emphasizes foundational concepts that frequently cause
            confusion, such as the difference between rates and outcomes,
            balances and totals, or recurring charges versus one-time amounts.
          </p>
          <p>
            The concepts tested here appear across many financial products.
            Understanding whether a value represents a percentage, a time-based
            charge, or a cumulative result is essential for accurately reading
            financial information. These distinctions form the basis of informed
            financial awareness.
          </p>
        </section>

        <section className="space-y-4">
          <h3 className="text-2xl font-bold text-[#0B1B2B]">
            Why these concepts matter in real life
          </h3>
          <p>
            Misinterpreting financial terms can lead to incorrect assumptions
            about cost, growth, or obligation. For example, confusing an annual
            rate with a total amount can distort expectations about borrowing or
            saving. Treating a balance as a final cost rather than a snapshot in
            time can result in poor decisions.
          </p>
          <p>
            The ability to read and understand financial labels accurately is a
            practical skill that applies across everyday situations. This quiz
            focuses on strengthening that skill rather than testing advanced
            financial knowledge.
          </p>
        </section>

        <section className="space-y-4">
          <h3 className="text-2xl font-bold text-[#0B1B2B]">
            Common mistakes and misconceptions
          </h3>
          <p>
            Many people rely on informal definitions when thinking about
            finance, which often leads to misunderstandings. Terms that sound
            similar in conversation can have very different meanings in
            financial contexts. Common mistakes include assuming all fees work
            the same way, misunderstanding what a balance represents, or
            treating percentages and dollar amounts as interchangeable.
          </p>
          <p>
            This quiz highlights those problem areas by presenting terms in
            realistic contexts. Identifying where confusion occurs helps reveal
            gaps that are easy to overlook but important to correct.
          </p>
        </section>

        <section className="space-y-4">
          <h3 className="text-2xl font-bold text-[#0B1B2B]">
            How to improve your results
          </h3>
          <p>
            Improving performance on this quiz usually comes from slowing down
            and carefully reading how each term is framed. Paying attention to
            time references, units, and qualifiers often resolves confusion.
          </p>
          <p>
            Retaking the quiz after reviewing basic finance definitions can help
            reinforce accurate interpretation. Progress tends to come from
            repeated exposure to consistent terminology rather than
            memorization.
          </p>
        </section>

        <section className="space-y-4">
          <h3 className="text-2xl font-bold text-[#0B1B2B]">
            Exploring related finance topics
          </h3>
          <p>
            This quiz draws from multiple areas of personal finance, including
            saving, borrowing, and investing fundamentals. Building familiarity
            across related topics helps strengthen overall financial literacy
            and improves recognition across different contexts.
          </p>
        </section>
      </div>
    </section>
  );
}
