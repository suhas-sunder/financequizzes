export function QuizGuideSection() {
  return (
    <section className="mx-auto max-w-6xl px-4 sm:px-6 py-14 border-b border-slate-200">
      <div className="rounded-3xl border border-slate-200 bg-white p-6 sm:p-8 lg:p-10 shadow-sm">
        <div className="text-left sm:text-center">
          <div className="mb-4 inline-block rounded-full border border-slate-200 bg-slate-50 px-3 py-1 text-sm font-semibold text-[#0B1B2B]">
            Quiz format guide
          </div>
          <h2 className="text-3xl sm:text-4xl font-extrabold tracking-tight text-[#0B1B2B]">
            How the quiz format works
          </h2>
          <p className="mt-4 max-w-3xl sm:mx-auto text-slate-700 text-base sm:text-lg leading-relaxed">
            Each page is an interactive quiz, not a calculator and not a course. You answer 10 multiple choice questions,
            get immediate feedback, and finish with a score summary.
          </p>
        </div>

        <div className="mt-10 grid gap-4 sm:grid-cols-2 lg:grid-cols-4 text-left">
          <div className="rounded-2xl border border-slate-200 bg-slate-50 p-5">
            <div className="text-sm font-extrabold text-[#0B1B2B]">1</div>
            <h3 className="mt-2 text-lg font-bold text-[#0B1B2B]">Pick a topic</h3>
            <p className="mt-1 text-slate-700 text-base leading-relaxed">
              Choose a quiz category, then start a run.
            </p>
          </div>

          <div className="rounded-2xl border border-slate-200 bg-slate-50 p-5">
            <div className="text-sm font-extrabold text-[#0B1B2B]">2</div>
            <h3 className="mt-2 text-lg font-bold text-[#0B1B2B]">Answer once</h3>
            <p className="mt-1 text-slate-700 text-base leading-relaxed">
              Each question locks after you pick an option.
            </p>
          </div>

          <div className="rounded-2xl border border-slate-200 bg-slate-50 p-5">
            <div className="text-sm font-extrabold text-[#0B1B2B]">3</div>
            <h3 className="mt-2 text-lg font-bold text-[#0B1B2B]">Get feedback</h3>
            <p className="mt-1 text-slate-700 text-base leading-relaxed">
              You see correctness right away, then you move on.
            </p>
          </div>

          <div className="rounded-2xl border border-slate-200 bg-slate-50 p-5">
            <div className="text-sm font-extrabold text-[#0B1B2B]">4</div>
            <h3 className="mt-2 text-lg font-bold text-[#0B1B2B]">Finish with a score</h3>
            <p className="mt-1 text-slate-700 text-base leading-relaxed">
              Your score is correct answers out of 10, shown as a percent.
            </p>
          </div>
        </div>

        <div className="mt-8 flex flex-wrap items-center gap-2 justify-start sm:justify-center">
          <span className="rounded-full bg-slate-100 px-3 py-1 text-sm font-semibold text-slate-700">
            10 questions
          </span>
          <span className="rounded-full bg-slate-100 px-3 py-1 text-sm font-semibold text-slate-700">
            4 options
          </span>
          <span className="rounded-full bg-slate-100 px-3 py-1 text-sm font-semibold text-slate-700">
            randomized runs
          </span>
          <span className="rounded-full bg-slate-100 px-3 py-1 text-sm font-semibold text-slate-700">
            instant feedback
          </span>
        </div>

        <details className="group mt-10 rounded-2xl border border-slate-200 bg-white">
          <summary className="cursor-pointer list-none p-5 sm:p-6 outline-none focus-visible:ring-2 focus-visible:ring-teal-600 focus-visible:ring-offset-2 hover:bg-slate-50 transition">
            <div className="flex items-start justify-between gap-4">
              <span className="font-bold text-[#0B1B2B] text-lg">
                Read the full guide and privacy notes
              </span>
              <span
                aria-hidden="true"
                className="mt-1 inline-flex h-6 w-6 items-center justify-center rounded-full border border-slate-200 text-slate-600 group-open:rotate-45 transition"
              >
                +
              </span>
            </div>
          </summary>

          <div className="px-5 sm:px-6 pb-6 pt-0 text-slate-700 text-base sm:text-lg leading-relaxed space-y-6">
            <div>
              <h3 className="text-xl font-bold text-[#0B1B2B]">A simple expectation setter</h3>
              <ul className="mt-3 space-y-2">
                <li className="flex gap-3">
                  <span className="mt-2 h-2 w-2 shrink-0 rounded-full bg-slate-400" aria-hidden="true" />
                  Questions are general and written for unambiguous scoring.
                </li>
                <li className="flex gap-3">
                  <span className="mt-2 h-2 w-2 shrink-0 rounded-full bg-slate-400" aria-hidden="true" />
                  Results describe quiz performance only and are not personalized guidance.
                </li>
                <li className="flex gap-3">
                  <span className="mt-2 h-2 w-2 shrink-0 rounded-full bg-slate-400" aria-hidden="true" />
                  Some topics vary by country or policy, so wording stays high level by design.
                </li>
              </ul>
            </div>

            <div>
              <h3 className="text-xl font-bold text-[#0B1B2B]">Stats and device storage</h3>
              <p className="mt-3">
                Many quizzes show simple in run stats like how many you have answered and how many you have correct so far.
                Some pages also track a best streak in local storage so it can be restored after a reload.
              </p>
              <p className="mt-3">
                If you use a private window, clear site data, or switch devices, those locally saved stats may reset. The
                quizzes still work normally either way.
              </p>
            </div>

            <div>
              <h3 className="text-xl font-bold text-[#0B1B2B]">What is in scope</h3>
              <p className="mt-3">
                Expect common concepts like budgeting, debt, interest, risk, diversification, and retirement terminology at a
                high level. The intent is conceptual understanding, not country specific compliance.
              </p>
              <p className="mt-3">
                Because quizzes need unambiguous scoring, each question has four options and exactly one correct answer.
                If a topic requires nuanced exceptions, the question pool avoids those edge cases.
              </p>
            </div>
          </div>
        </details>
      </div>
    </section>
  );
}
