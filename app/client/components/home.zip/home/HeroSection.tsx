import { Link } from "react-router";

type HeroSectionProps = {
  financeChallengeHref: string;
  personalFinanceChallengeHref: string;
  investingChallengeHref: string;
  financeQuestionsHref: string;
  allCategoriesAnchorHref?: string;
};

export function HeroSection({
  financeChallengeHref,
  personalFinanceChallengeHref,
  investingChallengeHref,
  financeQuestionsHref,
  allCategoriesAnchorHref = "#all-categories",
}: HeroSectionProps) {
  return (
    <section
      className="relative bg-[#F9FBFD] pt-10 pb-14 px-4 border-b border-slate-200"
      style={{
        backgroundImage:
          "radial-gradient(circle at 1px 1px, #E5E9EE 1px, transparent 0)",
        backgroundSize: "20px 20px",
      }}
    >
      <div className="mx-auto max-w-6xl">
        <div className="text-left sm:text-center">
          <div className="mb-4 inline-block rounded-full bg-teal-100 px-4 pt-1 pb-2 text-xs font-semibold text-teal-700">
            Test your finance and investing knowledge
          </div>

          <h1 className="text-3xl sm:text-5xl font-extrabold text-[#0B1B2B] mb-5 tracking-tight">
            Finance &amp; Investing Quizzes
          </h1>

          <p className="max-w-2xl sm:mx-auto text-slate-700 text-base sm:text-lg leading-relaxed">
            Take a 10 question challenge quiz and get a simple score summary. Each run is randomized from a larger question pool.
          </p>

          <div className="mt-8 flex flex-col sm:flex-row gap-3 sm:justify-center">
            <Link
              to={financeChallengeHref}
              prefetch="intent"
              className="rounded-xl bg-teal-700 px-6 py-3 text-white font-semibold text-base cursor-pointer hover:bg-teal-800 transition focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-teal-600 focus-visible:ring-offset-2 text-center"
            >
              Start the Finance Quiz
            </Link>
          </div>

          <div className="mt-4 text-sm sm:text-base text-slate-700">
            <div className="flex flex-wrap gap-x-3 gap-y-2 sm:justify-center">
              <Link
                to={personalFinanceChallengeHref}
                prefetch="intent"
                className="underline cursor-pointer hover:no-underline focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-teal-600 focus-visible:ring-offset-2"
              >
                Personal Finance Quiz
              </Link>
              <span className="text-slate-400" aria-hidden="true">
                ·
              </span>
              <Link
                to={investingChallengeHref}
                prefetch="intent"
                className="underline cursor-pointer hover:no-underline focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-teal-600 focus-visible:ring-offset-2"
              >
                Investing Quiz
              </Link>
            </div>

            <p className="mt-4 text-sm text-slate-600">
              Want a study-friendly list instead? Browse{" "}
              <Link
                to={financeQuestionsHref}
                prefetch="intent"
                className="underline cursor-pointer hover:no-underline focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-teal-600 focus-visible:ring-offset-2"
              >
                finance quiz questions and answers
              </Link>
              .
            </p>

            <p className="mt-2 text-sm text-slate-600">
              Or browse{" "}
              <a
                href={allCategoriesAnchorHref}
                className="underline cursor-pointer hover:no-underline focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-teal-600 focus-visible:ring-offset-2"
              >
                all quiz categories
              </a>
              .
            </p>
          </div>
        </div>
      </div>
    </section>
  );
}
