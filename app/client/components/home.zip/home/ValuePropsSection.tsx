import { Link } from "react-router";

type ValuePropsSectionProps = {
  financeChallengeHref: string;
  allCategoriesAnchorHref: string;
};

export function ValuePropsSection({
  financeChallengeHref,
  allCategoriesAnchorHref,
}: ValuePropsSectionProps) {
  return (
    <section className="mx-auto max-w-6xl px-4 sm:px-6 py-14 border-b border-slate-200">
      <div className="grid lg:grid-cols-2 gap-10 items-start">
        <div className="text-left">
          <h2 className="text-3xl font-extrabold mb-4 text-[#0B1B2B]">
            10 question challenges designed for fast self checks
          </h2>
          <p className="text-slate-700 text-base sm:text-lg leading-relaxed">
            Answer 10 multiple choice questions, see instant feedback, and finish with a clear score. No signup.
          </p>

          <p className="mt-4 text-slate-700 text-base sm:text-lg leading-relaxed">
            These quizzes are educational only and do not provide recommendations.
          </p>
        </div>

        <div className="rounded-3xl border border-slate-200 bg-[#F9FBFD] p-8 text-left">
          <h3 className="text-xl font-bold mb-4 text-[#0B1B2B]">
            What you can expect
          </h3>
          <ul className="space-y-3 text-slate-700 text-base sm:text-lg leading-relaxed">
            <li className="flex gap-3">
              <span className="mt-2 h-2 w-2 shrink-0 rounded-full bg-emerald-500" aria-hidden="true" />
              <span>Quick scoring with a 10 question format</span>
            </li>
            <li className="flex gap-3">
              <span className="mt-2 h-2 w-2 shrink-0 rounded-full bg-emerald-500" aria-hidden="true" />
              <span>Topic focused quizzes across money, credit, investing, banking, and economics</span>
            </li>
            <li className="flex gap-3">
              <span className="mt-2 h-2 w-2 shrink-0 rounded-full bg-emerald-500" aria-hidden="true" />
              <span>No signup and no personal data required</span>
            </li>
          </ul>

          <div className="mt-6 flex flex-col sm:flex-row gap-3">
            <Link
              to={financeChallengeHref}
              prefetch="intent"
              className="rounded-xl bg-teal-700 px-5 py-2.5 text-white font-semibold text-base cursor-pointer hover:bg-teal-800 transition text-center focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-teal-600 focus-visible:ring-offset-2"
            >
              Take the Finance Quiz
            </Link>
            <a
              href={allCategoriesAnchorHref}
              className="rounded-xl border border-slate-300 bg-white px-5 py-2.5 text-[#0B1B2B] font-semibold text-base cursor-pointer hover:bg-slate-50 transition text-center focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-teal-600 focus-visible:ring-offset-2"
            >
              Browse all categories
            </a>
          </div>
        </div>
      </div>
    </section>
  );
}
