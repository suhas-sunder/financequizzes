import { Link } from "react-router";

export function SeoContentSection() {
  return (
    <section className="mx-auto max-w-6xl px-4 sm:px-6 py-14 border-b border-slate-200">
      <div className="rounded-3xl border border-slate-200 bg-white p-6 sm:p-8 lg:p-10 shadow-sm text-left">
        <h2 className="text-3xl sm:text-4xl font-extrabold tracking-tight text-[#0B1B2B]">
          Finance quizzes that check real world basics
        </h2>

        <div className="mt-6 space-y-5 text-slate-700 text-base sm:text-lg leading-relaxed">
          <p>
            FinanceQuizzes is built for one job: help you confirm what you actually know about money, credit, investing,
            and the economy. Each page is a 10 question multiple choice challenge designed to surface gaps fast, then let
            you try again with a different mix of questions.
          </p>

          <details className="group rounded-2xl border border-slate-200 bg-white">
            <summary className="cursor-pointer list-none p-5 sm:p-6 outline-none focus-visible:ring-2 focus-visible:ring-teal-600 focus-visible:ring-offset-2 hover:bg-slate-50 transition">
              <div className="flex items-start justify-between gap-4">
                <span className="font-bold text-[#0B1B2B] text-lg">
                  Read the full guide and topic picks
                </span>
                <span
                  aria-hidden="true"
                  className="mt-1 inline-flex h-6 w-6 items-center justify-center rounded-full border border-slate-200 text-slate-600 group-open:rotate-45 transition"
                >
                  +
                </span>
              </div>
            </summary>

            <div className="px-5 sm:px-6 pb-6 pt-0 space-y-5">
              <p>
                If you searched for a <strong>personal finance quiz</strong>, an <strong>investing quiz</strong>, a{" "}
                <strong>credit quiz</strong>, or an <strong>economics quiz</strong>, you are in the right place.
              </p>

              <p>
                Most people learn finance in fragments: a headline about inflation, a conversation about credit cards, a bank
                form, a workplace benefits choice, or a first investing account. That is why these quizzes focus on the
                concepts that show up in everyday decisions. You will see questions about trade offs, incentives, interest,
                risk, diversification, budgets, and how prices send signals.
              </p>

              <h3 className="text-2xl font-bold text-[#0B1B2B] pt-2">
                How the 10 question format works
              </h3>
              <p>
                Each quiz is a short run of ten questions. You answer once per question, get immediate feedback, and finish
                with a clear score summary. Runs are randomized from a larger pool so repeating a quiz is useful practice
                instead of memorizing the order.
              </p>

              <p>
                This structure matches what most searchers want: a quick way to test knowledge and get answers. It can adapt
                to broad intent like finance quiz while still staying beginner friendly.
              </p>

              <h3 className="text-2xl font-bold text-[#0B1B2B] pt-2">
                Pick a topic that matches your goal
              </h3>

              <p>
                If you want the broadest check, start with the{" "}
                <Link
                  to="/finance-quiz"
                  prefetch="intent"
                  className="underline cursor-pointer hover:no-underline focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-teal-600 focus-visible:ring-offset-2"
                >
                  Finance Quiz
                </Link>
                .
              </p>

              <p>
                If you want practical day to day coverage, the{" "}
                <Link
                  to="/personal-finance-quiz"
                  prefetch="intent"
                  className="underline cursor-pointer hover:no-underline focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-teal-600 focus-visible:ring-offset-2"
                >
                  Personal Finance Quiz
                </Link>{" "}
                focuses on budgeting, saving, debt, and credit basics.
              </p>

              <p>
                If you want markets and risk concepts, the{" "}
                <Link
                  to="/investing-quiz"
                  prefetch="intent"
                  className="underline cursor-pointer hover:no-underline focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-teal-600 focus-visible:ring-offset-2"
                >
                  Investing Quiz
                </Link>{" "}
                covers risk, diversification, and time horizon basics.
              </p>

              <p>
                If your searches are about borrowing, the{" "}
                <Link
                  to="/banking-and-credit-quiz"
                  prefetch="intent"
                  className="underline cursor-pointer hover:no-underline focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-teal-600 focus-visible:ring-offset-2"
                >
                  Banking and Credit Quiz
                </Link>{" "}
                and{" "}
                <Link
                  to="/credit-basics-quiz"
                  prefetch="intent"
                  className="underline cursor-pointer hover:no-underline focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-teal-600 focus-visible:ring-offset-2"
                >
                  Credit Basics Quiz
                </Link>{" "}
                cover account terms, scores, utilization, and interest basics.
              </p>

              <p>
                If you want beginner economics fundamentals, the{" "}
                <Link
                  to="/economics-basics-quiz"
                  prefetch="intent"
                  className="underline cursor-pointer hover:no-underline focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-teal-600 focus-visible:ring-offset-2"
                >
                  Economics Basics Quiz
                </Link>{" "}
                is the simplest starting point.
              </p>
            </div>
          </details>
        </div>
      </div>
    </section>
  );
}
