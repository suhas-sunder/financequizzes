import { json } from "@remix-run/node";
import type { Route } from "./+types/home";
import { useLoaderData } from "react-router";

import { HeroSection } from "../client/components/home/HeroSection";
import { PriorityPathsSection } from "../client/components/home/PriorityPathsSection";
import { ValuePropsSection } from "../client/components/home/ValuePropsSection";
import { QuizGuideSection } from "../client/components/home/QuizGuideSection";
import { SeoContentSection } from "../client/components/home/SeoContentSection";
import { AllCategoriesSection } from "../client/components/home/AllCategoriesSection";
import { FaqSection } from "../client/components/home/FaqSection";
import { JsonLd } from "../client/components/home/JsonLd";

import {
  allCategoryRoutes,
  priorityRoutes,
} from "../client/components/home/homeRoutes";
import {
  buildCanonicalUrl,
  getPreferredSiteUrl,
} from "../client/components/home/seo.server";

interface LoaderData {
  faqs: { q: string; a: string }[];
  seo: {
    canonicalUrl: string;
    siteUrl: string;
  };
}

export function meta({
  data,
}: Route.MetaArgs & { data?: LoaderData | undefined }) {
  const title = "Finance Quizzes | Free 10 Question Challenge Quizzes";
  const description =
    "Test your finance and investing knowledge with free 10 question challenge quizzes. Instant feedback, randomized questions, no signup required.";

  const canonicalUrl =
    data?.seo?.canonicalUrl ?? "https://www.financequizzes.com/";
  const siteUrl = data?.seo?.siteUrl ?? "https://www.financequizzes.com";

  return [
    { title },
    { name: "description", content: description },

    { tagName: "link", rel: "canonical", href: canonicalUrl },

    { property: "og:title", content: title },
    { property: "og:description", content: description },
    { property: "og:type", content: "website" },
    { property: "og:url", content: canonicalUrl },

    { name: "twitter:card", content: "summary_large_image" },
    { name: "twitter:title", content: title },
    { name: "twitter:description", content: description },

    { name: "robots", content: "index,follow" },
    { name: "theme-color", content: "#0B1B2B" },

    { name: "application-name", content: "FinanceQuizzes" },
    { name: "generator", content: "Remix" },

    { tagName: "meta", name: "og:site_name", content: "FinanceQuizzes" },
    { tagName: "meta", name: "twitter:domain", content: new URL(siteUrl).host },
  ];
}

export function loader({ request }: Route.LoaderArgs) {
  const siteUrl = getPreferredSiteUrl(request);
  const canonicalUrl = buildCanonicalUrl(request, siteUrl);

  return json<LoaderData>({
    faqs: [
      {
        q: "Are the quizzes free?",
        a: "Yes. All quizzes are free and you can take them as many times as you like.",
      },
      {
        q: "Do I need an account?",
        a: "No. There is no signup. Some stats may be saved locally in your browser.",
      },
      {
        q: "How long is each quiz?",
        a: "Each challenge quiz has 10 multiple choice questions and usually takes just a few minutes.",
      },
      {
        q: "Do the quizzes include answers?",
        a: "Yes. You get immediate feedback after each question and a score summary at the end.",
      },
      {
        q: "Is this financial advice?",
        a: "No. These quizzes are for educational purposes only and do not provide financial or investment advice.",
      },
    ],
    seo: { canonicalUrl, siteUrl },
  });
}

export default function Home({}: Route.ComponentProps) {
  const { faqs, seo } = useLoaderData<LoaderData>();

  const origin = seo.siteUrl.replace(/\/+$/, "");
  const pageUrl = seo.canonicalUrl;

  const orgId = `${origin}/#organization`;
  const websiteId = `${origin}/#website`;
  const webpageId = `${origin}/#webpage`;
  const appId = `${origin}/#app`;

  return (
    <main className="bg-white text-[#0B1B2B]">
      <HeroSection
        financeChallengeHref="/finance-quiz"
        personalFinanceChallengeHref="/personal-finance-quiz"
        investingChallengeHref="/investing-quiz"
        financeQuestionsHref="/finance-quiz-questions"
        allCategoriesAnchorHref="#all-categories"
      />

      <PriorityPathsSection routes={priorityRoutes} />

      <ValuePropsSection
        financeChallengeHref="/finance-quiz"
        allCategoriesAnchorHref="#all-categories"
      />

      <QuizGuideSection />

      <SeoContentSection />

      <AllCategoriesSection routes={allCategoryRoutes} />

      <FaqSection faqs={faqs} />

      <JsonLd
        data={{
          "@context": "https://schema.org",
          "@graph": [
            {
              "@type": "Organization",
              "@id": orgId,
              name: "FinanceQuizzes",
              url: origin,
            },
            {
              "@type": "WebSite",
              "@id": websiteId,
              url: origin,
              name: "FinanceQuizzes",
              publisher: { "@id": orgId },
            },
            {
              "@type": "WebPage",
              "@id": webpageId,
              url: pageUrl,
              name: "Finance Quizzes",
              isPartOf: { "@id": websiteId },
              about: { "@id": appId },
            },
            {
              "@type": "SoftwareApplication",
              "@id": appId,
              name: "FinanceQuizzes",
              applicationCategory: "EducationalApplication",
              operatingSystem: "Web",
              url: origin,
              offers: {
                "@type": "Offer",
                price: "0",
                priceCurrency: "USD",
              },
              publisher: { "@id": orgId },
            },
            ...(faqs?.length
              ? [
                  {
                    "@type": "FAQPage",
                    "@id": `${origin}/#faq`,
                    isPartOf: { "@id": webpageId },
                    mainEntity: faqs.slice(0, 5).map((f) => ({
                      "@type": "Question",
                      name: f.q,
                      acceptedAnswer: {
                        "@type": "Answer",
                        text: f.a,
                      },
                    })),
                  },
                ]
              : []),
          ],
        }}
      />
    </main>
  );
}
